//////////////////////////////Tiny Encryption Algorithm//////////////////////////////


This project demonstrates the encryption and decryption of grayscale images using the TEA (Tiny Encryption Algorithm) in both ECB (Electronic Codebook) and CBC (Cipher Block Chaining) modes.


--This is a simple read-me file demonstrating how to execute the TEA encryption/decryption program

----------------------------------------------------------------------

1.Adding the needed files to run the program.

--the program is written using python so you may use VS code or any other python3 program

--using the VS code open the select the folder to add all the files to the file explorer

--Or just add the TEAcryptoooo.py file along with any image you prefer i used Aqsa.bmp

----------------------------------------------------------------------

2. Running the code 

--run the code using the terminal in the VS code by adding a new terminal on the screen

--run the command <<<<<<<>>>>>>>python TEAcryptoooo.py<<<<<<<>>>>>>> in the terminal

----------------------------------------------------------------------

3. interacting with the program

-- KEY 
the program asks the user to enter a key which is a { 32 hex }
    ex:{ 1234123456785678abcdabcdefefefef } <<< the key should be as a string format or the program will keep validating it 

-- Initializing Vector
the program asks the user to enter a IV for the CBC mode which is a { 16 hex }
    ex:{   1122334455667788  } <<< the IV also should be in a string format or the program will validate it 

-- Image path
the program asks the user to enter the program path for the image 
    if the image is within the directory just add the image file along with the file type 
       ex:{   Aqsa.bmp   } <<< the image is in the directory 

    if the image is in another place just copy the path of it and provide it to the code
       ex:{   "C:\Users\odysh\Downloads\Aqsa.bmp"  } <<< the image isn't in the program directory


---------------------------------------------------------------------
4.expected output 

--the output of the program should be a encrypted/decrypted .bmp image of the inserted image using tiny encryption algorithm  in the two modes CBC/ECB



//////////////////////////////
<<<<<<odyshbayeh-1201462>>>>>>
//////////////////////////////
